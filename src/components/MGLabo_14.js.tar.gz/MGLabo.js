import React, { useEffect, useState } from 'react'
import { useNavigate } from "react-router-dom"
import Presidence from './images/logo_csr.png';

function makeid(length) {
  let result = '';
  const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
  const charactersLength = characters.length;
  let counter = 0;
  while (counter < length) {
    result += characters.charAt(Math.floor(Math.random() * charactersLength));
    counter += 1;
  }
  return result;
}

const MgLabo = ({ socket }) => {
  const initialData = [
    { Client: 0, nom: "Aucune Tache", selectedStatus: "En Attente" }
  ];
  const navigate = useNavigate()
  const [errorMessages, setErrorMessages] = useState({});
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [numClient, setNumClient] = useState("");
  const [etatAnalyses, setEtatAnalyses] = useState(0);
  const [nomClient, setNomClient] = useState("");
  const [newValue, setValue] = useState("");
  const [list, updateList] = useState(initialData);
  const [clients, setClients] = useState([]);
  const [loading, setLoading] = useState(true);
  const [position, setPosition] = useState({ x: 100, y: 100 });
  const [isDragging, setIsDragging] = useState(false);
  const [selectedStatus, setSelectedStatus] = useState("");
  const [isUpdating, setIsUpdating] = useState(false);
  const [showDelayedText, setShowDelayedText] = useState(false);
  const [ClientUpdated, setClientUpdated] = useState({ initialData });

  const database = [
    {
      username: "Alex",
      password: "SansPasse"
    },
    {
      username: "Hardem",
      password: "SansPasse"
    },
    {
      username: "Labo",
      password: "12345678"
    }
  ];
  // =======================================================================
  function sirAcceuil() {
    navigate("/PageAcceuil");
  }
  const handleLogin = (event) => {
    event.preventDefault();
    var { uname, pass } = document.forms[0];
    const userData = database.find((user) => user.username === uname.value);

    if (userData) {
      if (userData.password !== pass.value) {
        setErrorMessages({ name: "pass", message: errors.pass });
      } else {
        setIsSubmitted(true);
      }
    } else {
      setErrorMessages({ name: "uname", message: errors.uname });
    }

    setTimeout(() => {
      setShowDelayedText(true);
    }, 2000);
  };
  const ListItem = ({ id, Client, nom, onRemoveClick }) => {
    const handleStatusChange = async (e) => {
      const newStatus = e.target.value;

      setIsUpdating(true);
      //socket.emit("updateFinished", newStatus);

      try {
        //const success = await updateLaboStatus(Client, newStatus);
        if (newStatus === "Terminé") {
          //alert(ListItem.length);
          onRemoveClick(id);
        }
        if (newStatus == "En attente") {
          setEtatAnalyses(0);
        }
        if (newStatus == "En cours") {
          setEtatAnalyses(1);
        }
        if (newStatus == "Terminé") {
          setEtatAnalyses(2);
        }
        if (newStatus == "Annulé") {
          setEtatAnalyses(3);
        }
 socket.emit("MajEtatAnalyses", etatAnalyses)
      } catch (error) {
        console.error("Erreur de mise à jour:", error);
      } finally {
        setIsUpdating(false);


      }
             

    };

    const getStatusText = (statusCode) => {
      const statusMap = {
        0: "En attente",
        1: "En cours",
        2: "Terminé",
        3: "Annulé"
      };
      return statusMap[statusCode] || "En attente";
    };
    return (
      <div className='list_row'>
        <label className='glow-on-hover_field  flex-row'>
          {Client} <span> | </span>
        </label>
        <label className='glow-on-hover_list flex-row'>
          {nom} <span> | </span>
        </label>

        <select
          value={getStatusText(etatAnalyses)}
          onChange={handleStatusChange}
          className="status-select"
          disabled={isUpdating}
        >
          <option value="En attente">En attente</option>
          <option value="En cours">En cours</option>
          <option value="Terminé">Terminé</option>
          <option value="Annulé">Annulé</option>
        </select>
      </div>
    );
  };
  // =======================================================================

  const renderErrorMessage = (name) =>
    name === errorMessages.name && (
      <div className="message_erreur">{errorMessages.message}
      </div>
    );

  const renderForm = (
    <div className="form">
      <form className='form_margin BC' onSubmit={handleLogin}>

        <br></br>
        <br></br>

        <label className='sous_titre'>Utilisateur </label>
        <input className='utilisateur_interne' minLength={4} type="text" name="uname" required />
        {renderErrorMessage("uname")}

        <label className='sous_titre'>Code d'accès</label>
        <input className='utilisateur_interne' minLength={8} type="password" name="pass" required />
        {renderErrorMessage("pass")}

        <div className='ftt__footer BC'>

          <button className='home__cta'>Connexion</button>
        </div>


      </form>
    </div>
  );

  // ===============================================================

  const ListExample = () => {

    const removeItem = id => {

      updateList(list.filter(item => item.id !== id));
    };

    return (
      <div className='global_list' >

        {list.map(item => (
          <ListItem key={item.id}  {...item} onRemoveClick={removeItem} />
        ))
        }

      </div>
    );
  };

  //------------------------------------------------------------------------
  useEffect(() => {
    socket.on("tache_labo", data => {
      setEtatAnalyses(data[2]);
      setValue(data);
      const newList = [...list, { id: list.length, Client: data[0], nom: data[1], selectedStatus: data[2] }];
      updateList(newList);
    });
  })
  return (
    <>
      <div style={{ height: '80vh', width: '60vh', position: 'relative' }}>
        <div
          className="floating-component"
          style={{
            left: position.x,
            top: position.y,
            position: "absolute",
            cursor: isDragging ? "grabbing" : "grab",
          }}
        //onMouseDownCapture={handleMouseDown}
        >

          <div className="entete TC">
            <div className='titre_entete'>
              <h2 className='titre_entete'>CSR - N'Djamena - TCHAD</h2>
              <h3 className='sous_titre_entete'>Laboratoire d'Analyses Médicale</h3>
              <br></br>
              <br></br>
              <h2 className='sous_titre_entete'>File des travaux techniques</h2>

            </div>
          </div>
          {isSubmitted ? <div>
            <div>
              <div >
                <ListExample />
              </div>

              <div className="Labo__footer BC">
                <button className="glow-on-hover_bouton_Labo" type="button" onClick={sirAcceuil} id='Lyo1' >Fin Session</button>
              </div>
            </div>
          </div> : renderForm}

        </div>
      </div>

    </>
  )
}

export default MgLabo
