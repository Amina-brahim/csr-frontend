import React, { useEffect, useState, Component } from 'react';
import './style.css';
import jsonString from './labo.json'; // Assuming the stringified JSON is stored here
import JsonToTable from './JsonToTable'
import TableComponent from './TableComponent';

const MGApercuLabo = ({ socket }) => {
  
return (
  <TableComponent data={jsonString} />
);
      }
export default MGApercuLabo;  
/*
<div>
<JsonToTable data={jsonString}/>
</div>
*/