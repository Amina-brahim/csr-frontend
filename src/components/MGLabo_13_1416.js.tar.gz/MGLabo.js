import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { io } from 'socket.io-client';

const socket = io('http://localhost:3001');

const MgLabo = () => {
  const [clients, setClients] = useState([]);
  const [loading, setLoading] = useState(true);
  const [position, setPosition] = useState({ x: 100, y: 100 });
  const [isDragging, setIsDragging] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [errorMessages, setErrorMessages] = useState({});
  const [selectedStatus, setSelectedStatus] = useState('En attente');
  const [isUpdating, setIsUpdating] = useState(false);
  const [showDelayedText, setShowDelayedText] = useState(false);
  const [ClientUpdated, setClientUpdated] = useState({
    numClient: 0,
    StatusLabo: selectedStatus,
  });
  const initialData = [
    { Client: 0, nom: "Aucune Tache à faire", selectedStatus: "En Attente" }
  ];
  const [list, updateList] = useState(initialData);

  const database = [
    {
      username: "Alex",
      password: "SansPasse"
    },
    {
      username: "Hardem",
      password: "SansPasse"
    },
    {
      username: "Labo",
      password: "12345678"
    }
  ];

  const ListItem = ({ Client, nom, onRemoveClick }) => {
    const handleStatusChange = async (orderNumber, newStatus) => {
      try {
        await axios.put(`http://localhost:4500/api/clients/${orderNumber}`, {
          status: newStatus
        });

        if (newStatus === "Terminé") {
          setClients(prev => prev.filter(c => c.orderNumber !== orderNumber));
        }
      } catch (error) {
        console.error("Erreur mise à jour:", error);
        alert("Échec de la mise à jour");
      }
    };
    /*const handleStatusChange = async (e) => {
      const newStatus = e.target.value;
      setSelectedStatus(newStatus);
      setIsUpdating(true);
              socket.emit("updateFinished", newStatus);

      try {
        const success = await updateLaboStatus(Client, newStatus);
        if (newStatus === "Terminé") {
          onRemoveClick(Client);
        }
      } catch (error) {
        console.error("Erreur de mise à jour:", error);
      } finally {
        setIsUpdating(false);
      }
    };*/

    return (
      <div className='list_row'>
        <label className='glow-on-hover_field  flex-row'>
          {Client} <span> | </span>
        </label>
        <label className='glow-on-hover_list flex-row'>
          {nom} <span> | </span>
        </label>

        <select
          value={selectedStatus}
          onChange={handleStatusChange}
          className="status-select"
          disabled={isUpdating} // Seulement désactivé pendant la mise à jour
        >
          <option value="En attente">En attente</option>
          <option value="En cours">En cours</option>
          <option value="Terminé">Terminé</option>
          <option value="Annulé">Annulé</option>
        </select>

        {isUpdating && <span>Mise à jour...</span>}
      </div>
    );
  };
  // ===============================================================
  const handleLogin = (event) => {
    event.preventDefault();
    var { uname, pass } = document.forms[0];
    const userData = database.find((user) => user.username === uname.value);

    if (userData) {
      if (userData.password !== pass.value) {
        setErrorMessages({ name: "pass", message: errors.pass });
      } else {
        setIsSubmitted(true);
      }
    } else {
      setErrorMessages({ name: "uname", message: errors.uname });
    }

    setTimeout(() => {
      setShowDelayedText(true);
    }, 2000);
  };

  // ===============================================================

  function sirAcceuil() {
    navigate("/PageAcceuil");
  }
  // =======================================================================

  const renderErrorMessage = (name) =>
    name === errorMessages.name && (
      <div className="message_erreur">{errorMessages.message}
      </div>
    );

  const renderForm = (
    <div className="form">
      <form className='form_margin BC' onSubmit={handleLogin}>

        <br></br>
        <br></br>

        <label className='sous_titre'>Utilisateur </label>
        <input className='utilisateur_interne' minLength={4} type="text" name="uname" required />
        {renderErrorMessage("uname")}

        <label className='sous_titre'>Code d'accès</label>
        <input className='utilisateur_interne' minLength={8} type="password" name="pass" required />
        {renderErrorMessage("pass")}

        <div className='ftt__footer BC'>

          <button className='home__cta'>Connexion</button>
        </div>


      </form>
    </div>
  );

  // ===============================================================
  const ListExample = () => {
    const removeItem = id => {
      let tmpCSRID = list.filter(item => item.id == id);
      updateList(list.filter(item => item.Client !== id));
    };

    return (
      <div className='global_list' >

        {list.map(item => (
          <ListItem key={item.Client}  {...item} onRemoveClick={removeItem} />
        ))
        }

      </div>
    );
  };
  // ===============================================================
  useEffect(() => {
    // Charger les clients initiaux
    const fetchClients = async () => {
      try {
        const response = await axios.get('http://localhost:4500/api/clients');
        setClients(response.data.filter(c => c.IsLaboratorized !== "Terminé"));
        setLoading(false);
      } catch (error) {
        console.error("Erreur:", error);
        setLoading(false);
      }
    };

    fetchClients();

    // Écouter les nouveaux clients
    socket.on('new_client', (newClient) => {
      setClients(prev => [...prev, newClient]);
    });

    return () => {
      socket.off('new_client');
    };
  }, []);



  if (loading) return <div>Chargement...</div>;

  return (
    <>
      <div style={{ height: '80vh', width: '60vh', position: 'relative' }}>
        <div
          className="floating-component"
          style={{
            left: position.x,
            top: position.y,
            position: "absolute",
            cursor: isDragging ? "grabbing" : "grab",
          }}
        //onMouseDownCapture={handleMouseDown}
        >

          <div className="entete TC">
            <div className='titre_entete'>
              <h2 className='titre_entete'>CSR - N'Djamena - TCHAD</h2>
              <h3 className='sous_titre_entete'>Laboratoire d'Analyses Médicale</h3>
              <br></br>
              <br></br>
              <h2 className='sous_titre_entete'>File des travaux techniques</h2>

            </div>
          </div>
          {isSubmitted ? <div>
            <div>
              <div >
                <ListExample />
              </div>

              <div className="Labo__footer BC">
                <button className="glow-on-hover_bouton_Labo" type="button" onClick={sirAcceuil} id='Lyo1' >Fin Session</button>
              </div>
            </div>
          </div> : renderForm}

        </div>
      </div>

    </>
  )
};

export default MgLabo;